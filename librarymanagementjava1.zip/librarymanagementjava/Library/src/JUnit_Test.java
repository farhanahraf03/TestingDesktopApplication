import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

import java.sql.*;

public class JUnit_Test 
{
	Connection conn;
	
	@Before
	public void setup()
	{
		conn = DB.getConnection();
	}
	
	@After
	public void dismantle()throws SQLException
	{
		conn.close();
	}
	
	@Test
	public void validateConnection()
	{
		assertNotNull(conn);
		System.out.println("JDBC connection tested successfully");
	}
	
	@Test
	public void validateInsertBook()
	{
		int res = BookDao.save("F@565", "And then there were none", "Agatha Christie", "Big niBBa", 6);
		assertEquals(1,res);
		System.out.println("Book inserted successfully");
	}
	
	@Test
	public void validateViewBook()
	{
		boolean res = IssueBookDao.checkBook("F@565");
		assertTrue(res);
		System.out.println("New Book found");
	}
	
}
