import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

import java.sql.*;

public class JUnit_Test1 
{
	Connection conn;

	@Before
	public void setup()
	{
		conn = DB.getConnection();
	}
	
	@After
	public void dismantle() throws SQLException
	{
		conn.close();
	}
	
	@Test
	public void validateLibrarianInsert()
	{
		int res = LibrarianDao.save("Farhan","farhan123","email.farhan@protonmail.com","Salisbury Park","Pune","8329916949");
		assertEquals(1,res);
		
		System.out.println("New librarian inserted successfully");
	}
	
	@Test
	public void validateViewLibrarian()
	{
		boolean res = LibrarianDao.validate("Farhan","farhan123");
		
		assertTrue(res);
		
		System.out.println("New librarian found");
	}

}
